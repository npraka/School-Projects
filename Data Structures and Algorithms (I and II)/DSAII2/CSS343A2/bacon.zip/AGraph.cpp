#include "AGraph.h"



AGraph::AGraph()
{
}


AGraph::~AGraph()
{
}
