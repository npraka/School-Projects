#pragma once
#include <string>

#include <iostream>
#include <fstream>
using namespace std;
class ABST
{
public:
	ABST();
	~ABST();
	bool AddActor(string s);
private:

	struct Vertex {
		string actor[3];
		string movies[];


	
		
	};
};

