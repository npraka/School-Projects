#include "ABST.h"



ABST::ABST()
{

}


ABST::~ABST()
{
}
