#include "ABST.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main()
{

	ifstream File;
	File.open("bacon.txt");
	char cur;
	//while (File.get(cur))
	//{
	//	cout << cur;
	//}

	int asciiVal=0; //represents current ascii get value for assessment
	string curWord = ""; //Will be the word to get added by Add() and then reset to ""


	while (!File.eof())//While still taking in input
	{
		asciiVal = File.get();//After process for character is completed, go to next character
		


		while (asciiVal < 123 && asciiVal > 64)//Last Name
		{

			curWord += asciiVal;
			

			asciiVal = File.get();
			

		}
		if (asciiVal == 44)
		{
			curWord += asciiVal;
		}

		cout << "Last Name: " ;
		cout << curWord << endl;
        
		
		curWord = "";
		asciiVal = File.get();
		if (asciiVal == 32)
		{

			asciiVal = File.get();
		while (asciiVal < 123 && asciiVal > 64)//First Name
		{

			curWord += asciiVal;


			asciiVal = File.get();


		}
		cout << "First Name: ";
		cout << curWord << endl;


		}
		while(asciiVal)

		



		

		

	}
	//////////////////////////////////////////////////////////////////////

	

ABST();
}
	

