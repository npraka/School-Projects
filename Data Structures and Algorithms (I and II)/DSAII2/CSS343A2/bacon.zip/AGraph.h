#pragma once
#include <string>
#include <iostream>
#include <fstream>
using namespace std;

class AGraph
{
public:
	AGraph();
	~AGraph();
	
private:
	struct Node {
		
		string name;

	};




};

